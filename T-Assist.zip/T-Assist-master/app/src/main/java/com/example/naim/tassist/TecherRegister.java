package com.example.naim.tassist;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.CardView;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class TecherRegister extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_techer_register);


        final EditText t_et_name = (EditText) findViewById(R.id.t_et_name);
        final EditText t_et_id = (EditText) findViewById(R.id.t_et_id);
        final EditText t_et_email = (EditText) findViewById(R.id.t_et_email);
        final EditText t_et_username = (EditText) findViewById(R.id.t_et_username);
        final EditText t_et_password = (EditText) findViewById(R.id.t_et_password);
        final CardView TeacherCard = (CardView) findViewById(R.id.teacher_cardView);

        TeacherCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String Name=t_et_name.getText().toString();
                final int Id=Integer.parseInt(t_et_id.getText().toString());
                final String Email=t_et_email.getText().toString();
                final String Username=t_et_username.getText().toString();
                final String Password=t_et_password.getText().toString();
                Response.Listener<String> responseListner = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse =new JSONObject(response);
                            boolean success= jsonResponse.getBoolean("success");
                            if (success)
                            {
                                Toast.makeText(TecherRegister.this, "Registration Completed", Toast.LENGTH_LONG).show();
                                Intent intent =new Intent(TecherRegister.this,TeacherLogin.class);
                                TecherRegister.this.startActivity(intent);
                            }
                            else
                            {
                                AlertDialog.Builder builder = new AlertDialog.Builder(TecherRegister.this);
                                builder.setMessage("Register Failed!!!")
                                        .setNegativeButton("Retry",null)
                                        .create()
                                        .show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };

                TeacherRegisterRequest registerRequest =new TeacherRegisterRequest(Name,Id,Email,Username,Password,responseListner);
                RequestQueue queue= Volley.newRequestQueue(TecherRegister.this);
                queue.add(registerRequest);
            }
        });

    }
}
