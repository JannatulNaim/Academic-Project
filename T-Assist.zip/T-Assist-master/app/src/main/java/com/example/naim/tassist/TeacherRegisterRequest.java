package com.example.naim.tassist;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class TeacherRegisterRequest extends StringRequest {

    private static final String TEACHER_REGISTER_REQUEST_URL="https://naimcse28.000webhostapp.com/teacherregister.php";
    private Map<String,String> params;
    public TeacherRegisterRequest(String Name, int Id, String Email,String Username, String Password, Response.Listener<String>listener)
    {
        super(Method.POST,TEACHER_REGISTER_REQUEST_URL,listener,null);
        params=new HashMap<>();
        params.put("Name",Name);
        params.put("Id",Id+"");
        params.put("Email",Email);
        params.put("Username",Username);
        params.put("Password",Password);

    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}

