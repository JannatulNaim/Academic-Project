package com.example.naim.tassist;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Window;
import android.widget.TextView;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        final TextView tv_name = (TextView) findViewById(R.id.showname);
        final TextView tv_sem = (TextView) findViewById(R.id.showsem);
        final TextView Welcome = (TextView) findViewById(R.id.textView3);

        Intent intent =getIntent();
        String Name =intent.getStringExtra("Name");
        String Username =intent.getStringExtra("Username");
        String Semester =intent.getStringExtra("Semester");

        String message = Name + " Welcome to Main Activity";
        Welcome.setText(message);
        tv_name.setText(Username);
        tv_sem.setText(Semester);
    }
}
