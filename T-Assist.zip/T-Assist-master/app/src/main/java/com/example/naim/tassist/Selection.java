package com.example.naim.tassist;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;

public class Selection extends Activity {

    Button teacher,student;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_selection);

        teacher=(Button)findViewById(R.id.btn_teacher);
        student=(Button)findViewById(R.id.btn_student);

        teacher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(Selection.this,TeacherLogin.class);
                Selection.this.startActivity(intent);
            }
        });
        student.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(Selection.this,LogIn.class);
                Selection.this.startActivity(intent);
            }
        });

    }
}
