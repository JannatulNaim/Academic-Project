package com.example.naim.tassist;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class TeacherLogin extends Activity {
    Button tResister;
    EditText tUsername,tPassword;
    CardView tCardView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_teacher_login);


        tResister=(Button)findViewById(R.id.bt_teacher_register);
        tUsername=(EditText)findViewById(R.id.et_teacher_user);
        tPassword=(EditText)findViewById(R.id.et_teacher_pass);
        tCardView=(CardView)findViewById(R.id.teacher_cardView);

        tResister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(TeacherLogin.this,TecherRegister.class);
                TeacherLogin.this.startActivity(intent);
            }
        });


        tCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String tuname = tUsername.getText().toString();
                final String tupass = tPassword.getText().toString();

                Response.Listener<String> responseListner = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {

                            JSONObject jsonResponse =new JSONObject(response);

                            boolean success= jsonResponse.getBoolean("success");

                            if (success)
                            {
                                Toast.makeText(TeacherLogin.this, "Login Successful", Toast.LENGTH_SHORT).show();
                                String Name=jsonResponse.getString("Name");
                                String Username=jsonResponse.getString("Username");
                                String Email=jsonResponse.getString("Email");

                                Intent intent =new Intent(TeacherLogin.this,MainActivity.class);
                                intent.putExtra("Name",Name);
                                intent.putExtra("Username",Username);
                                intent.putExtra("Email",Email);

                                TeacherLogin.this.startActivity(intent);
                            }
                            else
                            {
                                AlertDialog.Builder builder = new AlertDialog.Builder(TeacherLogin.this);
                                builder.setMessage("Login Failed!!!")
                                        .setNegativeButton("Retry",null)
                                        .create()
                                        .show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };
                TeacherLoginRequest loginRequest = new TeacherLoginRequest(tuname,tupass,responseListner);
                RequestQueue queue= Volley.newRequestQueue(TeacherLogin.this);
                queue.add(loginRequest);
            }
        });

    }
}
