package com.example.naim.tassist;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.CardView;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class LogIn extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_log_in);

       final Button register=(Button)findViewById(R.id.bt_register);
        final CardView cardView1=(CardView)findViewById(R.id.cardView);
        final EditText et_username=(EditText)findViewById(R.id.et_user);
        final EditText et_password=(EditText)findViewById(R.id.et_pass);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(LogIn.this,Resister.class);
                LogIn.this.startActivity(intent);
            }
        });

        cardView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String uname = et_username.getText().toString();
                final String upass = et_password.getText().toString();

                Response.Listener<String> responseListner = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {

                            JSONObject jsonResponse =new JSONObject(response);

                            boolean success= jsonResponse.getBoolean("success");

                            if (success)
                            {
                                Toast.makeText(LogIn.this, "Login Successful", Toast.LENGTH_SHORT).show();
                                String Name=jsonResponse.getString("Name");
                                String Username=jsonResponse.getString("Username");
                                String Semester=jsonResponse.getString("Semester");

                                Intent intent =new Intent(LogIn.this,MainActivity.class);
                                intent.putExtra("Name",Name);
                                intent.putExtra("Username",Username);
                                intent.putExtra("Semester",Semester);
                                LogIn.this.startActivity(intent);
                            }
                            else
                            {
                                AlertDialog.Builder builder = new AlertDialog.Builder(LogIn.this);
                                builder.setMessage("Login Failed!!!")
                                        .setNegativeButton("Retry",null)
                                        .create()
                                        .show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };
                LoginRequest loginRequest = new LoginRequest(uname,upass,responseListner);
                RequestQueue queue= Volley.newRequestQueue(LogIn.this);
                queue.add(loginRequest);
            }
        });
    }
}
