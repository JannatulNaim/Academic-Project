                                                      T-Assist 
                                                 Md. Jannatul Naim
                                                 Sem: 6th,  Sec: A
                                                  Dept.of CSE,VU
                                               Varendra  University 
1. Motivation:
The T-Assist has been built to eliminate the time and effort wasted in taking attendances.
It also reduces the amount of paper resources needed in attendance data management.
This is an android mobile app. It’s built to be used for our faculty so that our teacher may take student attendance on their phones. 
 
2. Overview:
The system is divided into following modules: 
 * Student Attendance List Creation:  Once this App is installed on a phone, 
   it allows user to create a student attendance sheet consisting of name, roll number, date, Absent/Present/Sick/Late mark and subject.
   He has to fill student names along with associated roll numbers. 
 
 * Attendance Marking:
   The faculty has the list on his phone now. He may see the list call roll numbers 
   and select absent id the student is absent or select present if student is present and so on. 
 
 * Attendance Storage:
   This data is now stored in the faculty mobile phone. Faculty may also view it anytime on their phone. 
 
3. Background:
* Android Studio
* PHP, MySQL for Database 
* Java 
* 000webhost

4. Advantage:
* Eliminates the use of paperwork
* This gives the overall performance of class in attendance
* The app is easy to install and use

5. Disadvantage:
The system can be run on android platform only.
Though most of the mobiles now are android version and available in reasonable rate so it won’t be a big issue 

THANK YOU , 
Be Connected, 
-Naim Noyon
