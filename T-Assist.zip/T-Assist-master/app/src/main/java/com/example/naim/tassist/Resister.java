package com.example.naim.tassist;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class Resister extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_resister);

        final EditText et_name = (EditText) findViewById(R.id.t_et_name);
        final EditText et_id = (EditText) findViewById(R.id.t_et_id);
        final EditText et_semester = (EditText) findViewById(R.id.et_semester);
        final EditText et_section = (EditText) findViewById(R.id.et_section);
        final EditText et_username = (EditText) findViewById(R.id.t_et_username);
        final EditText et_password = (EditText) findViewById(R.id.t_et_password);
        final CardView cardView2 = (CardView) findViewById(R.id.teacher_cardView);



        cardView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String Name=et_name.getText().toString();
                final int Id=Integer.parseInt(et_id.getText().toString());
                final String Semester=et_semester.getText().toString();
                final String Section=et_section.getText().toString();
                final String Username=et_username.getText().toString();
                final String Password=et_password.getText().toString();
                Response.Listener<String> responseListner = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse =new JSONObject(response);
                            boolean success= jsonResponse.getBoolean("success");
                            if (success)
                            {
                                Toast.makeText(Resister.this, "Registration Completed", Toast.LENGTH_LONG).show();
                                Intent intent =new Intent(Resister.this,LogIn.class);
                                Resister.this.startActivity(intent);
                            }
                           else
                            {
                                AlertDialog.Builder builder = new AlertDialog.Builder(Resister.this);
                                builder.setMessage("Register Failed!!!")
                                        .setNegativeButton("Retry",null)
                                        .create()
                                        .show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };

                RegisterRequest registerRequest =new RegisterRequest(Name,Id,Semester,Section,Username,Password,responseListner);
                RequestQueue queue= Volley.newRequestQueue(Resister.this);
                queue.add(registerRequest);
            }
        });

    }
}
